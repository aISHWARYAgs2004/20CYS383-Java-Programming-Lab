package com.amrita.jpl.cys21004.practice.basic;

/**
 * @author Aishwarya GS
 */

public class Adding_Two_Numbers {
    public static void main(String[] args) {

        /**
         * Addition
         * @param args default argument
         */

        int a = 12, b = 34, sum;
        sum = a + b;
        System.out.println("Sum = "+sum);

    }
}
