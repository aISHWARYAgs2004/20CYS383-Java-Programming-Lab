package com.amrita.jpl.cys21004.practice.basic;

/**
 * @author Aishwarya GS
 */


public class HelloWorld {
    public static void main(String[] args) {
        /**
         * Hello
         * @param args default argument
         */

        System.out.println("Hello world!");
    }
}